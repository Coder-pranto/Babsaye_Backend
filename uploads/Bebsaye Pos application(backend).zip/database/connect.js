const mongoose = require("mongoose");
const colors = require('colors'); // Import the colors package

const connectDB = async (url) => {
  try {
    mongoose.set('strictQuery', false); // Mongoose v6 deprecates "strictQuery"
    // const conn = await mongoose.connect(url);
    mongoose.connect(url, () => {
      console.log("Mongo connected");
  });

    // console.log(colors.green.bold.bgWhite(`MongoDB connected: ${conn.connection.host}`)); 
  } catch (error) {
    console.error(colors.red.bold(`Error: ${error.message}`)); 
    process.exit(1);
  }
};

module.exports = connectDB;

